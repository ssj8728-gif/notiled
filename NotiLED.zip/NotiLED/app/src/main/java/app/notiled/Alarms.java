package app.notiled;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;

/** Inexact, battery-friendly alarms used to repeat the light and to run the test. */
final class Alarms {
    static final String REPEAT = "app.notiled.REPEAT";
    static final String TEST = "app.notiled.TEST";

    private static PendingIntent pi(Context c, String action) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, 0, i, flags);
    }

    static void set(Context c, long delayMs, String action) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = SystemClock.elapsedRealtime() + Math.max(1000, delayMs);
        if (Build.VERSION.SDK_INT >= 23) {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi(c, action));
        } else {
            am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi(c, action));
        }
    }

    static void cancel(Context c, String action) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi(c, action));
    }

    private Alarms() {
    }
}
