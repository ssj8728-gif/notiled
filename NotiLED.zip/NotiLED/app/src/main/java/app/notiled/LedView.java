package app.notiled;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.LinearInterpolator;

/**
 * Draws the light on a pure black background. Black pixels are switched off on AMOLED/OLED panels,
 * so only the few lit pixels use power. Used both on the real light screen and in the preview.
 */
final class LedView extends View {
    static final int DOT = 0, RING = 1, BAR = 2, EDGE = 3;
    static final int PULSE = 0, BLINK = 1, SOLID = 2;

    private int[] colors = {0xFF22D3EE};
    private int idx, style, anim;
    private float xp = .5f, yp = .04f, size = 40f, level = 1f;
    private ValueAnimator va;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private Shader glow;
    private final Shader[] edge = new Shader[4];

    LedView(Context c) {
        super(c);
    }

    void config(int[] cols, int style, int anim, int xPct, int yPct, float sizePx) {
        this.colors = cols != null && cols.length > 0 ? cols : new int[]{0xFF22D3EE};
        this.idx = 0;
        this.style = style;
        this.anim = anim;
        this.xp = xPct / 100f;
        this.yp = yPct / 100f;
        this.size = sizePx;
        rebuild();
        invalidate();
    }

    void rounded(final float radiusPx) {
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
        setClipToOutline(true);
    }

    private static int alpha(int color, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF);
    }

    private void rebuild() {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        int col = colors[idx % colors.length];
        float cx = w * xp, cy = h * yp, r = size / 2f;
        glow = new RadialGradient(cx, cy, r * 2.6f,
                new int[]{alpha(col, 0xCC), alpha(col, 0x55), alpha(col, 0)},
                new float[]{0.38f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        float t = size * 1.4f;
        int a0 = alpha(col, 0xDD), a1 = alpha(col, 0);
        edge[0] = new LinearGradient(0, 0, 0, t, a0, a1, Shader.TileMode.CLAMP);
        edge[1] = new LinearGradient(0, h, 0, h - t, a0, a1, Shader.TileMode.CLAMP);
        edge[2] = new LinearGradient(0, 0, t, 0, a0, a1, Shader.TileMode.CLAMP);
        edge[3] = new LinearGradient(w, 0, w - t, 0, a0, a1, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild();
    }

    /** Starts the animation. Call from onResume; the solid style needs no animator (zero CPU). */
    void start() {
        stop();
        if (anim == SOLID) {
            level = 1f;
            invalidate();
            return;
        }
        va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(anim == PULSE ? 1800 : 1400);
        va.setRepeatCount(ValueAnimator.INFINITE);
        va.setInterpolator(new LinearInterpolator());
        va.addUpdateListener(an -> {
            float t = (Float) an.getAnimatedValue();
            if (anim == PULSE) level = 0.12f + 0.88f * (float) (0.5 - 0.5 * Math.cos(t * 2 * Math.PI));
            else level = t < 0.35f ? 1f : 0f;
            invalidate();
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationRepeat(Animator a) {
                if (colors.length > 1) {
                    idx = (idx + 1) % colors.length; // next color on every cycle
                    rebuild();
                }
            }
        });
        va.start();
    }

    /** Stops the animation. Call from onPause. */
    void stop() {
        if (va != null) {
            va.cancel();
            va = null;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(Color.BLACK);
        if (glow == null) return;
        int w = getWidth(), h = getHeight();
        int col = colors[idx % colors.length];
        int a = (int) (255 * level);
        float cx = w * xp, cy = h * yp, r = size / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);

        switch (style) {
            case RING: {
                float sw = Math.max(2f, r * 0.28f);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(sw * 3.4f);
                p.setColor(alpha(col, (int) (a * 0.22f)));
                c.drawCircle(cx, cy, r, p);
                p.setStrokeWidth(sw);
                p.setColor(alpha(col, a));
                c.drawCircle(cx, cy, r, p);
                break;
            }
            case BAR: {
                float bw = size * 4f, bh = Math.max(3f, size * 0.4f);
                float x = Math.min(Math.max(cx, bw / 2f), w - bw / 2f);
                rf.set(x - bw / 2f, cy - bh / 2f, x + bw / 2f, cy + bh / 2f);
                float g = bh * 1.4f;
                rf.inset(-g, -g);
                p.setColor(alpha(col, (int) (a * 0.2f)));
                c.drawRoundRect(rf, bh + g, bh + g, p);
                rf.inset(g, g);
                p.setColor(alpha(col, a));
                c.drawRoundRect(rf, bh / 2f, bh / 2f, p);
                break;
            }
            case EDGE: {
                float t = size * 1.4f;
                p.setShader(edge[0]);
                p.setAlpha(a);
                c.drawRect(0, 0, w, t, p);
                p.setShader(edge[1]);
                p.setAlpha(a);
                c.drawRect(0, h - t, w, h, p);
                p.setShader(edge[2]);
                p.setAlpha(a);
                c.drawRect(0, 0, t, h, p);
                p.setShader(edge[3]);
                p.setAlpha(a);
                c.drawRect(w - t, 0, w, h, p);
                p.setShader(null);
                break;
            }
            default: { // DOT
                p.setShader(glow);
                p.setAlpha(a);
                c.drawCircle(cx, cy, r * 2.6f, p);
                p.setShader(null);
                p.setColor(alpha(col, a));
                c.drawCircle(cx, cy, r, p);
                break;
            }
        }
    }
}
