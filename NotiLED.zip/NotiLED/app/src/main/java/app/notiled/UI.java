package app.notiled;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Tiny helpers that build the settings screens in code: no layout XML, no UI libraries. */
final class UI {
    static final int BG = 0xFF000000, CARD = 0xFF12161C, TEXT = 0xFFF1F5F9, SUB = 0xFF8B95A5, ACC = 0xFF22D3EE;

    interface Fmt {
        String f(int v);
    }

    interface ColorCb {
        void on(int color);
    }

    static float dp(Context c, int v) {
        return v * c.getResources().getDisplayMetrics().density;
    }

    static int px(Context c, int v) {
        return Math.round(dp(c, v));
    }

    static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, CharSequence s, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    static LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b, Context c) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(px(c, l), px(c, t), px(c, r), px(c, b));
        return p;
    }

    /** Pads a screen's root view by the system bars (needed for edge-to-edge on Android 15+). */
    @SuppressWarnings("deprecation")
    static void insets(final View root, final int padDp) {
        final Context c = root.getContext();
        final int p = px(c, padDp);
        root.setPadding(p, p, p, p);
        root.setOnApplyWindowInsetsListener((v, in) -> {
            v.setPadding(p + in.getSystemWindowInsetLeft(), p + in.getSystemWindowInsetTop(),
                    p + in.getSystemWindowInsetRight(), p + in.getSystemWindowInsetBottom());
            return in;
        });
    }

    static LinearLayout card(Context c, LinearLayout parent) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(c, CARD, 16));
        int p = px(c, 14);
        l.setPadding(p, px(c, 10), p, px(c, 10));
        parent.addView(l, lp(-1, -2, 0, 0, 0, 12, c));
        return l;
    }

    static void header(Context c, LinearLayout parent, int res) {
        TextView t = text(c, c.getString(res).toUpperCase(), 12, ACC, true);
        t.setLetterSpacing(0.08f);
        parent.addView(t, lp(-2, -2, 6, 10, 0, 6, c));
    }

    static void note(Context c, LinearLayout parent, int res) {
        TextView t = text(c, c.getString(res), 12, SUB, false);
        parent.addView(t, lp(-1, -2, 0, 4, 0, 4, c));
    }

    static Button button(Context c, int res, View.OnClickListener l) {
        Button b = new Button(c);
        b.setText(res);
        b.setAllCaps(false);
        b.setTextColor(Color.BLACK);
        b.setBackground(round(c, ACC, 12));
        b.setOnClickListener(l);
        return b;
    }

    // ------------------------------------------------------------------ rows

    static Switch toggle(final Context c, LinearLayout card, int label, final String key, final Runnable change) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(px(c, 48));
        TextView t = text(c, c.getString(label), 15, TEXT, false);
        row.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        Switch s = new Switch(c);
        s.setChecked(Prefs.on(c, key));
        s.setOnCheckedChangeListener((b, on) -> {
            Prefs.put(c, key, on ? 1 : 0);
            if (change != null) change.run();
        });
        row.addView(s);
        card.addView(row);
        return s;
    }

    static void slider(final Context c, LinearLayout card, int label, final String key, final int min, int max,
                       final Fmt fmt, final Runnable change) {
        final TextView t = text(c, "", 15, TEXT, false);
        final int cur = Math.max(min, Math.min(max, Prefs.get(c, key)));
        final String name = c.getString(label);
        t.setText(name + "  ·  " + fmt.f(cur));
        card.addView(t, lp(-1, -2, 0, 8, 0, 0, c));
        SeekBar sb = new SeekBar(c);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                t.setText(name + "  ·  " + fmt.f(p + min));
                if (user) {
                    Prefs.put(c, key, p + min);
                    if (change != null) change.run();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        card.addView(sb, lp(-1, -2, 0, 0, 0, 4, c));
    }

    static void chips(final Context c, LinearLayout card, int label, final String key, int[] labels,
                      final Runnable change) {
        card.addView(text(c, c.getString(label), 15, TEXT, false), lp(-1, -2, 0, 8, 0, 6, c));
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout row = new LinearLayout(c);
        hs.addView(row);
        final int n = labels.length;
        final Runnable paint = () -> {
            int sel = Prefs.get(c, key);
            for (int i = 0; i < n; i++) {
                TextView t = (TextView) row.getChildAt(i);
                boolean on = i == sel;
                t.setBackground(round(c, on ? ACC : 0xFF1F2630, 18));
                t.setTextColor(on ? Color.BLACK : TEXT);
            }
        };
        for (int i = 0; i < n; i++) {
            final int idx = i;
            TextView t = text(c, c.getString(labels[i]), 14, TEXT, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(px(c, 14), px(c, 8), px(c, 14), px(c, 8));
            t.setOnClickListener(v -> {
                Prefs.put(c, key, idx);
                paint.run();
                if (change != null) change.run();
            });
            row.addView(t, lp(-2, -2, 0, 0, 8, 0, c));
        }
        paint.run();
        card.addView(hs, lp(-1, -2, 0, 0, 0, 6, c));
    }

    static void colorRow(final Context c, LinearLayout card, int label, final String key, final Runnable change) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(px(c, 48));
        row.addView(text(c, c.getString(label), 15, TEXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final View dot = new View(c);
        dot.setBackground(round(c, Prefs.get(c, key), 20));
        row.addView(dot, new LinearLayout.LayoutParams(px(c, 34), px(c, 34)));
        row.setOnClickListener(v -> pick(c, Prefs.get(c, key), col -> {
            Prefs.put(c, key, col);
            dot.setBackground(round(c, col, 20));
            if (change != null) change.run();
        }));
        card.addView(row);
    }

    // ------------------------------------------------------------------ color picker

    private static final int[] PALETTE = {
            0xFFF87171, 0xFFFB923C, 0xFFFACC15, 0xFF4ADE80, 0xFF2DD4BF, 0xFF22D3EE,
            0xFF60A5FA, 0xFF818CF8, 0xFFC084FC, 0xFFF472B6, 0xFFFB7185, 0xFFFFFFFF};

    static void pick(final Context c, int initial, final ColorCb cb) {
        final int[] cur = {initial | 0xFF000000};
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = px(c, 20);
        root.setPadding(pad, pad, pad, px(c, 8));

        final View prev = new View(c);
        prev.setBackground(round(c, cur[0], 12));
        root.addView(prev, lp(-1, px(c, 44), 0, 0, 0, 14, c));

        int per = 6;
        LinearLayout row = null;
        for (int i = 0; i < PALETTE.length; i++) {
            if (i % per == 0) {
                row = new LinearLayout(c);
                row.setGravity(Gravity.CENTER);
                root.addView(row, lp(-1, -2, 0, 0, 0, 6, c));
            }
            final int col = PALETTE[i];
            View sw = new View(c);
            sw.setBackground(round(c, col, 22));
            sw.setOnClickListener(v -> {
                cur[0] = col;
                prev.setBackground(round(c, col, 12));
            });
            row.addView(sw, lp(px(c, 40), px(c, 40), 5, 0, 5, 0, c));
        }

        SeekBar hue = new SeekBar(c);
        hue.setMax(360);
        int[] hues = new int[7];
        for (int i = 0; i < 7; i++) hues[i] = Color.HSVToColor(new float[]{i * 60f % 360f, 1f, 1f});
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hues);
        g.setCornerRadius(dp(c, 6));
        g.setSize(-1, px(c, 12));
        hue.setProgressDrawable(g);
        hue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (!user) return;
                cur[0] = Color.HSVToColor(new float[]{p % 360, 1f, 1f});
                prev.setBackground(round(c, cur[0], 12));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(hue, lp(-1, -2, 0, 10, 0, 6, c));

        new AlertDialog.Builder(c, android.R.style.Theme_Material_Dialog_Alert)
                .setView(root)
                .setPositiveButton(android.R.string.ok, (d, w) -> cb.on(cur[0]))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private UI() {
    }
}
