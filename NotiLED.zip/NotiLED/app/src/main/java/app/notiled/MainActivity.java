package app.notiled;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Settings screen. Built in code, no layout files; nothing runs here once the screen is closed. */
public class MainActivity extends Activity {
    private LedView preview;
    private LinearLayout status;
    private final Runnable refresh = this::refreshPreview;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        sv.addView(root, new ScrollView.LayoutParams(-1, -2));
        UI.insets(sv, 16);
        setContentView(sv);

        root.addView(UI.text(this, getString(R.string.app_name), 26, UI.TEXT, true), UI.lp(-1, -2, 4, 8, 0, 12, this));

        // ---- status / permissions
        status = UI.card(this, root);

        // ---- live preview
        FrameLayout box = new FrameLayout(this);
        box.setBackground(UI.round(this, 0xFF2A323D, 30));
        int m = UI.px(this, 3);
        box.setPadding(m, m, m, m);
        preview = new LedView(this);
        preview.rounded(UI.dp(this, 27));
        box.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams plp = UI.lp(UI.px(this, 150), UI.px(this, 250), 0, 0, 0, 4, this);
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(box, plp);
        TextView pn = UI.text(this, getString(R.string.preview), 12, UI.SUB, false);
        pn.setGravity(Gravity.CENTER);
        root.addView(pn, UI.lp(-1, -2, 0, 0, 0, 12, this));

        // ---- general
        LinearLayout g = UI.card(this, root);
        UI.toggle(this, g, R.string.enabled, Prefs.ENABLED, null);
        g.addView(UI.button(this, R.string.test, v -> runTest()), UI.lp(-1, UI.px(this, 46), 0, 6, 0, 6, this));
        UI.note(this, g, R.string.test_hint);

        // ---- events
        UI.header(this, root, R.string.sec_events);
        LinearLayout e = UI.card(this, root);
        UI.toggle(this, e, R.string.ev_notif, Prefs.NOTIF, null);
        UI.toggle(this, e, R.string.ev_alerting, Prefs.ALERTING, null);
        UI.toggle(this, e, R.string.ev_batt, Prefs.BATT, null);
        UI.slider(this, e, R.string.ev_low, Prefs.LOW, 5, 50, v -> v + "%", null);
        UI.toggle(this, e, R.string.ev_pulse, Prefs.PULSE, null);

        // ---- colors
        UI.header(this, root, R.string.sec_colors);
        LinearLayout c = UI.card(this, root);
        UI.colorRow(this, c, R.string.c_charge, Prefs.C_CHARGE, refresh);
        UI.colorRow(this, c, R.string.c_full, Prefs.C_FULL, refresh);
        UI.colorRow(this, c, R.string.c_low, Prefs.C_LOW, refresh);
        UI.colorRow(this, c, R.string.c_msg, Prefs.C_MSG, refresh);
        UI.colorRow(this, c, R.string.c_mail, Prefs.C_MAIL, refresh);
        UI.colorRow(this, c, R.string.c_call, Prefs.C_CALL, refresh);
        UI.colorRow(this, c, R.string.c_social, Prefs.C_SOCIAL, refresh);
        UI.colorRow(this, c, R.string.c_rem, Prefs.C_REM, refresh);
        UI.colorRow(this, c, R.string.c_other, Prefs.C_OTHER, refresh);
        c.addView(UI.button(this, R.string.per_app, v -> startActivity(new Intent(this, AppsActivity.class))),
                UI.lp(-1, UI.px(this, 46), 0, 8, 0, 6, this));

        // ---- look
        UI.header(this, root, R.string.sec_style);
        LinearLayout s = UI.card(this, root);
        UI.chips(this, s, R.string.style, Prefs.STYLE,
                new int[]{R.string.st_dot, R.string.st_ring, R.string.st_bar, R.string.st_edge}, refresh);
        UI.chips(this, s, R.string.animation, Prefs.ANIM,
                new int[]{R.string.an_pulse, R.string.an_blink, R.string.an_solid}, refresh);
        UI.slider(this, s, R.string.size, Prefs.SIZE, 6, 48, v -> v + " dp", refresh);
        UI.slider(this, s, R.string.pos_x, Prefs.POSX, 0, 100, v -> v + "%", refresh);
        UI.slider(this, s, R.string.pos_y, Prefs.POSY, 0, 100, v -> v + "%", refresh);

        // ---- behavior
        UI.header(this, root, R.string.sec_behavior);
        LinearLayout h = UI.card(this, root);
        UI.slider(this, h, R.string.brightness, Prefs.BRIGHT, 1, 100, v -> v + "%", null);
        UI.chips(this, h, R.string.repeat, Prefs.REPEAT,
                new int[]{R.string.rp_off, R.string.rp_30s, R.string.rp_1m, R.string.rp_2m, R.string.rp_5m, R.string.rp_10m}, null);
        UI.toggle(this, h, R.string.quiet, Prefs.QUIET, null);
        UI.slider(this, h, R.string.quiet_from, Prefs.QFROM, 0, 23, v -> String.format("%02d:00", v), null);
        UI.slider(this, h, R.string.quiet_to, Prefs.QTO, 0, 23, v -> String.format("%02d:00", v), null);
        UI.toggle(this, h, R.string.lock_after, Prefs.LOCK, this::onLockToggled);
        UI.slider(this, h, R.string.lock_secs, Prefs.GLOW, 3, 60, v -> v + " s", null);
        UI.note(this, h, R.string.lock_hint);

        TextView tip = UI.text(this, getString(R.string.tip), 12, UI.SUB, false);
        root.addView(tip, UI.lp(-1, -2, 6, 6, 6, 24, this));

        refreshPreview();
    }

    @Override
    protected void onResume() {
        super.onResume();
        buildStatus();
        preview.start();
    }

    @Override
    protected void onPause() {
        preview.stop();
        super.onPause();
    }

    private void refreshPreview() {
        float scale = 150f / 360f; // the preview phone is much narrower than a real screen
        preview.config(new int[]{Prefs.get(this, Prefs.C_CALL), Prefs.get(this, Prefs.C_MSG),
                        Prefs.get(this, Prefs.C_MAIL), Prefs.get(this, Prefs.C_CHARGE)},
                Prefs.get(this, Prefs.STYLE), Prefs.get(this, Prefs.ANIM),
                Prefs.get(this, Prefs.POSX), Prefs.get(this, Prefs.POSY),
                UI.dp(this, Prefs.get(this, Prefs.SIZE)) * scale * 1.6f);
        preview.start();
    }

    // ------------------------------------------------------------------ permissions

    private boolean accessGranted() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void buildStatus() {
        status.removeAllViews();
        boolean any = false;

        if (!accessGranted()) {
            any = true;
            row(R.string.need_access, R.string.grant, v ->
                    startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            any = true;
            row(R.string.need_post, R.string.grant, v ->
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                any = true;
                row(R.string.need_fsi, R.string.grant, v -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ex) {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + getPackageName())));
                    }
                });
            }
        }
        if (!any) {
            status.addView(UI.text(this, "✓  " + getString(R.string.ready), 15, 0xFF4ADE80, true),
                    UI.lp(-1, -2, 0, 6, 0, 6, this));
        }
    }

    private void row(int msg, int btn, View.OnClickListener l) {
        status.addView(UI.text(this, getString(msg), 14, UI.TEXT, false), UI.lp(-1, -2, 0, 6, 0, 6, this));
        status.addView(UI.button(this, btn, l), UI.lp(-1, UI.px(this, 44), 0, 0, 0, 8, this));
    }

    private void runTest() {
        if (LedService.inst == null) {
            Toast.makeText(this, R.string.need_access, Toast.LENGTH_LONG).show();
            return;
        }
        Alarms.set(this, 5000, Alarms.TEST);
        Toast.makeText(this, R.string.test_started, Toast.LENGTH_LONG).show();
    }

    private void onLockToggled() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        if (dpm == null) return;
        ComponentName cn = new ComponentName(this, AdminReceiver.class);
        if (Prefs.on(this, Prefs.LOCK)) {
            if (!dpm.isAdminActive(cn)) {
                Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_why));
                startActivity(i);
            }
        } else if (dpm.isAdminActive(cn)) {
            dpm.removeActiveAdmin(cn); // give the privilege back when the feature is off
        }
    }
}
