package app.notiled;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Pick a custom color for any app, or mute it. Loaded only while this screen is open. */
public class AppsActivity extends Activity {
    private static final class Row {
        String pkg, label;
    }

    private final ArrayList<Row> all = new ArrayList<>();
    private final ArrayList<Row> shown = new ArrayList<>();
    private PackageManager pm;
    private SharedPreferences ap;
    private BaseAdapter adapter;
    private String filter = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pm = getPackageManager();
        ap = Prefs.apps(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        UI.insets(root, 16);
        setContentView(root);

        root.addView(UI.text(this, getString(R.string.apps_title), 22, UI.TEXT, true),
                UI.lp(-1, -2, 4, 8, 0, 4, this));
        TextView hint = UI.text(this, getString(R.string.apps_hint), 13, UI.SUB, false);
        root.addView(hint, UI.lp(-1, -2, 4, 0, 0, 10, this));

        EditText search = new EditText(this);
        search.setHint(R.string.apps_search);
        search.setSingleLine(true);
        search.setTextColor(UI.TEXT);
        search.setHintTextColor(UI.SUB);
        search.setBackground(UI.round(this, UI.CARD, 12));
        search.setPadding(UI.px(this, 14), UI.px(this, 10), UI.px(this, 14), UI.px(this, 10));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int c, int d) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int c, int d) {
                filter = s.toString().trim().toLowerCase(Locale.ROOT);
                refilter();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        root.addView(search, UI.lp(-1, -2, 0, 0, 0, 8, this));

        ListView lv = new ListView(this);
        lv.setDivider(null);
        adapter = new Adapter();
        lv.setAdapter(adapter);
        lv.setOnItemClickListener((p, v, pos, id) -> choose(shown.get(pos)));
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));

        new Thread(() -> {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(q, 0);
            final ArrayList<Row> rows = new ArrayList<>();
            ArrayList<String> seen = new ArrayList<>();
            for (ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || seen.contains(pkg)) continue;
                seen.add(pkg);
                Row r = new Row();
                r.pkg = pkg;
                r.label = String.valueOf(ri.loadLabel(pm));
                rows.add(r);
            }
            Collections.sort(rows, (x, y) -> x.label.compareToIgnoreCase(y.label));
            runOnUiThread(() -> {
                all.clear();
                all.addAll(rows);
                refilter();
            });
        }).start();
    }

    private void refilter() {
        shown.clear();
        for (Row r : all) {
            if (filter.isEmpty() || r.label.toLowerCase(Locale.ROOT).contains(filter)) shown.add(r);
        }
        adapter.notifyDataSetChanged();
    }

    private void choose(final Row r) {
        String[] items = {getString(R.string.app_default), getString(R.string.app_mute), getString(R.string.app_color)};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(r.label)
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        ap.edit().remove(r.pkg).apply();
                        adapter.notifyDataSetChanged();
                    } else if (which == 1) {
                        ap.edit().putInt(r.pkg, 0).apply();
                        adapter.notifyDataSetChanged();
                    } else {
                        int start = ap.getInt(r.pkg, 0);
                        if (start == 0) start = Prefs.get(this, Prefs.C_OTHER);
                        UI.pick(this, start, col -> {
                            ap.edit().putInt(r.pkg, col).apply();
                            adapter.notifyDataSetChanged();
                        });
                    }
                }).show();
    }

    private final class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int i) {
            return shown.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            LinearLayout row;
            ImageView icon;
            TextView name, sub;
            View dot;
            if (v == null) {
                row = new LinearLayout(AppsActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(UI.px(AppsActivity.this, 6), UI.px(AppsActivity.this, 8),
                        UI.px(AppsActivity.this, 6), UI.px(AppsActivity.this, 8));
                icon = new ImageView(AppsActivity.this);
                row.addView(icon, UI.lp(UI.px(AppsActivity.this, 40), UI.px(AppsActivity.this, 40), 0, 0, 12, 0, AppsActivity.this));
                LinearLayout col = new LinearLayout(AppsActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                name = UI.text(AppsActivity.this, "", 15, UI.TEXT, false);
                sub = UI.text(AppsActivity.this, "", 12, UI.SUB, false);
                col.addView(name);
                col.addView(sub);
                row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
                dot = new View(AppsActivity.this);
                row.addView(dot, new LinearLayout.LayoutParams(UI.px(AppsActivity.this, 26), UI.px(AppsActivity.this, 26)));
                row.setTag(new View[]{icon, name, sub, dot});
            } else {
                row = (LinearLayout) v;
            }
            View[] h = (View[]) row.getTag();
            icon = (ImageView) h[0];
            name = (TextView) h[1];
            sub = (TextView) h[2];
            dot = h[3];

            Row r = shown.get(i);
            name.setText(r.label);
            try {
                Drawable d = pm.getApplicationIcon(r.pkg);
                icon.setImageDrawable(d);
            } catch (Exception e) {
                icon.setImageDrawable(null);
            }
            if (ap.contains(r.pkg)) {
                int c = ap.getInt(r.pkg, 0);
                if (c == 0) {
                    sub.setText(R.string.app_muted);
                    dot.setBackground(UI.round(AppsActivity.this, 0xFF2A323D, 13));
                } else {
                    sub.setText(R.string.app_custom);
                    dot.setBackground(UI.round(AppsActivity.this, c, 13));
                }
            } else {
                sub.setText(R.string.app_default);
                dot.setBackground(UI.round(AppsActivity.this, 0xFF1F2630, 13));
            }
            return row;
        }
    }
}
