package app.notiled;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

/** All settings live in one tiny SharedPreferences file. Booleans are stored as 0/1. */
final class Prefs {
    static final String ENABLED = "enabled", NOTIF = "notif", ALERTING = "alerting",
            BATT = "batt", LOW = "low", PULSE = "pulse",
            C_CHARGE = "c_charge", C_FULL = "c_full", C_LOW = "c_low",
            C_MSG = "c_msg", C_MAIL = "c_mail", C_CALL = "c_call", C_SOCIAL = "c_social",
            C_REM = "c_rem", C_OTHER = "c_other",
            STYLE = "style", ANIM = "anim", SIZE = "size", POSX = "posx", POSY = "posy",
            BRIGHT = "bright", GLOW = "glow", REPEAT = "repeat", LOCK = "lock",
            QUIET = "quiet", QFROM = "qfrom", QTO = "qto";

    /** Options for the REPEAT setting (index -> milliseconds). */
    static final int[] REPEAT_MS = {0, 30000, 60000, 120000, 300000, 600000};

    private static final HashMap<String, Integer> DEF = new HashMap<>();

    static {
        DEF.put(ENABLED, 1);
        DEF.put(NOTIF, 1);
        DEF.put(ALERTING, 1);
        DEF.put(BATT, 1);
        DEF.put(LOW, 15);
        DEF.put(PULSE, 0);
        DEF.put(C_CHARGE, 0xFFFB923C); // orange
        DEF.put(C_FULL, 0xFF4ADE80);   // green
        DEF.put(C_LOW, 0xFFF87171);    // red
        DEF.put(C_MSG, 0xFF2DD4BF);    // teal
        DEF.put(C_MAIL, 0xFF60A5FA);   // blue
        DEF.put(C_CALL, 0xFFFB7185);   // rose
        DEF.put(C_SOCIAL, 0xFFC084FC); // purple
        DEF.put(C_REM, 0xFFFACC15);    // yellow
        DEF.put(C_OTHER, 0xFF22D3EE);  // cyan
        DEF.put(STYLE, 0);
        DEF.put(ANIM, 0);
        DEF.put(SIZE, 14);
        DEF.put(POSX, 50);
        DEF.put(POSY, 4);
        DEF.put(BRIGHT, 10);
        DEF.put(GLOW, 10);
        DEF.put(REPEAT, 3);            // every 2 minutes
        DEF.put(LOCK, 0);
        DEF.put(QUIET, 0);
        DEF.put(QFROM, 23);
        DEF.put(QTO, 7);
    }

    private static SharedPreferences spCfg, spApps;

    static SharedPreferences cfg(Context c) {
        if (spCfg == null) spCfg = c.getApplicationContext().getSharedPreferences("cfg", Context.MODE_PRIVATE);
        return spCfg;
    }

    /** Per-app overrides: package -> color. A value of 0 means "muted". Missing = default by category. */
    static SharedPreferences apps(Context c) {
        if (spApps == null) spApps = c.getApplicationContext().getSharedPreferences("apps", Context.MODE_PRIVATE);
        return spApps;
    }

    static int get(Context c, String key) {
        Integer d = DEF.get(key);
        return cfg(c).getInt(key, d == null ? 0 : d);
    }

    static boolean on(Context c, String key) {
        return get(c, key) != 0;
    }

    static void put(Context c, String key, int value) {
        cfg(c).edit().putInt(key, value).apply();
    }

    /** Maps a Notification.category value to the preference key holding its color. */
    static String catKey(String category) {
        if (category == null) return C_OTHER;
        switch (category) {
            case "msg":
                return C_MSG;
            case "email":
                return C_MAIL;
            case "call":
            case "missed_call":
                return C_CALL;
            case "social":
                return C_SOCIAL;
            case "alarm":
            case "reminder":
            case "event":
                return C_REM;
            default:
                return C_OTHER;
        }
    }

    /** Lower number = shown first when several colors are pending. */
    static int catPrio(String key) {
        switch (key) {
            case C_CALL:
                return 1;
            case C_MSG:
                return 2;
            case C_MAIL:
                return 3;
            case C_REM:
                return 4;
            case C_SOCIAL:
                return 5;
            default:
                return 6;
        }
    }

    private Prefs() {
    }
}
