package app.notiled;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;

/**
 * The only long-lived component. The system binds it (it is a notification listener), so the app
 * runs no foreground service, no polling and no wake locks. It keeps a tiny map of unread
 * notification colors, watches battery/screen broadcasts, and asks the system to show
 * {@link LedActivity} when the screen is off.
 */
public class LedService extends NotificationListenerService {
    static volatile LedService inst;

    static final int NOTIF_ID = 77;
    private static final String CHANNEL = "led";

    private static final class Item {
        final int prio, color;

        Item(int prio, int color) {
            this.prio = prio;
            this.color = color;
        }
    }

    private final HashMap<String, Item> pend = new HashMap<>();
    private boolean plugged, full, low, battInit, wasPlugged, wasFull, wasLow, receiving;
    private long lastGlow;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String act = i.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(act)) onBattery(i);
            else if (Intent.ACTION_SCREEN_OFF.equals(act)) onScreenOff();
            else if (Intent.ACTION_USER_PRESENT.equals(act)) Alarms.cancel(LedService.this, Alarms.REPEAT);
        }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onListenerConnected() {
        inst = this;
        if (!receiving) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_BATTERY_CHANGED);
            f.addAction(Intent.ACTION_SCREEN_OFF);
            f.addAction(Intent.ACTION_USER_PRESENT);
            Intent sticky;
            if (Build.VERSION.SDK_INT >= 33) sticky = registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED);
            else sticky = registerReceiver(rx, f);
            receiving = true;
            if (sticky != null) onBattery(sticky);
        }
        seed();
    }

    @Override
    public void onListenerDisconnected() {
        teardown();
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        if (inst == this) inst = null;
        if (receiving) {
            try {
                unregisterReceiver(rx);
            } catch (Exception ignored) {
            }
            receiving = false;
        }
        pend.clear();
        Alarms.cancel(this, Alarms.REPEAT);
    }

    /** Picks up notifications that were already showing when the service connected. */
    private void seed() {
        pend.clear();
        try {
            StatusBarNotification[] list = getActiveNotifications();
            RankingMap rm = getCurrentRanking();
            if (list != null) for (StatusBarNotification s : list) add(s, rm);
        } catch (Exception ignored) {
        }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) onScreenOff();
    }

    // ---------------------------------------------------------------- notifications

    @Override
    public void onNotificationPosted(StatusBarNotification sbn, RankingMap rm) {
        if (add(sbn, rm)) {
            show(collect(0), false);
            scheduleNext();
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn, RankingMap rm) {
        if (sbn != null) pend.remove(sbn.getKey());
        if (!hasPersistent()) Alarms.cancel(this, Alarms.REPEAT);
    }

    /** Returns true when the notification should make the light glow. */
    private boolean add(StatusBarNotification s, RankingMap rm) {
        if (s == null || getPackageName().equals(s.getPackageName())) return false;
        Notification n = s.getNotification();
        if (n == null || s.isOngoing()) return false;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return false;

        if (rm != null) {
            Ranking r = new Ranking();
            if (rm.getRanking(s.getKey(), r)) {
                if (!r.matchesInterruptionFilter()) return false; // hidden by Do Not Disturb
                if (Build.VERSION.SDK_INT >= 24 && Prefs.on(this, Prefs.ALERTING)) {
                    int imp = r.getImportance();
                    if (imp >= 0 && imp < NotificationManager.IMPORTANCE_DEFAULT) return false; // silent
                }
            }
        }

        String pkg = s.getPackageName();
        SharedPreferences ap = Prefs.apps(this);
        int color, prio;
        if (ap.contains(pkg)) {
            color = ap.getInt(pkg, 0);
            if (color == 0) return false; // muted app
            prio = 2;
        } else {
            String key = Prefs.catKey(n.category);
            color = Prefs.get(this, key);
            prio = Prefs.catPrio(key);
        }
        pend.put(s.getKey(), new Item(prio, color));
        return true;
    }

    // ---------------------------------------------------------------- battery & screen

    private void onBattery(Intent i) {
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int pct = scale > 0 ? level * 100 / scale : level;
        plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        full = plugged && (i.getIntExtra(BatteryManager.EXTRA_STATUS, 0) == BatteryManager.BATTERY_STATUS_FULL
                || pct >= 100);
        low = !plugged && pct >= 0 && pct <= Prefs.get(this, Prefs.LOW);

        if (battInit) {
            if (plugged && !wasPlugged) event(Prefs.get(this, Prefs.C_CHARGE));
            else if (full && !wasFull) event(Prefs.get(this, Prefs.C_FULL));
            else if (low && !wasLow) event(Prefs.get(this, Prefs.C_LOW));
        }
        wasPlugged = plugged;
        wasFull = full;
        wasLow = low;
        battInit = true;
    }

    private void event(int color) {
        if (!Prefs.on(this, Prefs.BATT)) return;
        show(collect(color), false);
        scheduleNext();
    }

    /** Screen went off: start the repeat cycle if something is still pending. */
    private void onScreenOff() {
        int ms = repeatMs();
        if (ms == 0 || !hasPersistent()) return;
        long since = SystemClock.elapsedRealtime() - lastGlow;
        Alarms.set(this, Math.max(2000, ms - since), Alarms.REPEAT);
    }

    // ---------------------------------------------------------------- repeat & test

    void onRepeat() {
        int[] colors = collect(0);
        if (colors.length == 0) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && pm.isInteractive()) return; // user is active; screen-off re-arms the cycle
        show(colors, false);
        scheduleNext();
    }

    void test() {
        show(new int[]{
                Prefs.get(this, Prefs.C_CALL), Prefs.get(this, Prefs.C_MSG),
                Prefs.get(this, Prefs.C_MAIL), Prefs.get(this, Prefs.C_SOCIAL)}, true);
    }

    private int repeatMs() {
        int i = Prefs.get(this, Prefs.REPEAT);
        return i >= 0 && i < Prefs.REPEAT_MS.length ? Prefs.REPEAT_MS[i] : 0;
    }

    private void scheduleNext() {
        int ms = repeatMs();
        if (ms > 0 && hasPersistent()) Alarms.set(this, ms, Alarms.REPEAT);
        else Alarms.cancel(this, Alarms.REPEAT);
    }

    // ---------------------------------------------------------------- what to show

    /** Distinct colors to cycle through, most important first. {@code extra} is a one-off event color. */
    private int[] collect(int extra) {
        ArrayList<Item> l = new ArrayList<>();
        if (extra != 0) l.add(new Item(-1, extra));
        if (Prefs.on(this, Prefs.NOTIF)) l.addAll(pend.values());
        if (Prefs.on(this, Prefs.BATT) && Prefs.on(this, Prefs.PULSE)) {
            if (plugged) l.add(new Item(9, Prefs.get(this, full ? Prefs.C_FULL : Prefs.C_CHARGE)));
            else if (low) l.add(new Item(0, Prefs.get(this, Prefs.C_LOW)));
        }
        Collections.sort(l, (a, b) -> a.prio - b.prio);
        int[] out = new int[Math.min(l.size(), 6)];
        int n = 0;
        outer:
        for (Item it : l) {
            for (int j = 0; j < n; j++) if (out[j] == it.color) continue outer;
            if (n == out.length) break;
            out[n++] = it.color;
        }
        return Arrays.copyOf(out, n);
    }

    private boolean hasPersistent() {
        return collect(0).length > 0;
    }

    private boolean quiet() {
        if (!Prefs.on(this, Prefs.QUIET)) return false;
        int from = Prefs.get(this, Prefs.QFROM), to = Prefs.get(this, Prefs.QTO);
        if (from == to) return false;
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return from < to ? (h >= from && h < to) : (h >= from || h < to);
    }

    // ---------------------------------------------------------------- showing the light

    private void show(int[] colors, boolean force) {
        if (colors.length == 0) return;
        if (!force && (!Prefs.on(this, Prefs.ENABLED) || quiet())) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isInteractive()) return; // the light is only for a dark screen

        lastGlow = SystemClock.elapsedRealtime();
        Intent i = new Intent(this, LedActivity.class)
                .putExtra("c", colors)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        if (Build.VERSION.SDK_INT < 29) {
            try {
                startActivity(i);
            } catch (Exception ignored) {
            }
        } else {
            postFullScreen(i); // Android 10+ blocks background activity starts; this is the sanctioned route
        }
    }

    private void postFullScreen(Intent i) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.enableLights(false);
            ch.setShowBadge(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            nm.createNotificationChannel(ch);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, 1, i, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_stat_led)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.led_text))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .setAutoCancel(true)
                .setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(15000);
        try {
            nm.notify(NOTIF_ID, b.build());
        } catch (Exception ignored) {
        }
    }
}
