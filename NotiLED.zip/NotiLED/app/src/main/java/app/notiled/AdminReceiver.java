package app.notiled;

import android.app.admin.DeviceAdminReceiver;

/** Only needed for the optional "turn screen off after glow" feature (force-lock policy). */
public class AdminReceiver extends DeviceAdminReceiver {
}
