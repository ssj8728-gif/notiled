package app.notiled;

import android.app.Activity;
import android.app.NotificationManager;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/**
 * Black full-screen window shown over the lock screen while the phone is idle. It does not hold the
 * screen on: the system's normal screen timeout (or the optional lock-after-glow) switches it off,
 * and the activity finishes itself when that happens.
 */
public class LedActivity extends Activity {
    private LedView view;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean rxOn;

    private final BroadcastReceiver rx = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            finish(); // screen turned off, or the user unlocked the phone
        }
    };

    private final Runnable lock = this::lockNow;
    private final Runnable giveUp = this::finish;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            w.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }

        WindowManager.LayoutParams lp = w.getAttributes();
        lp.screenBrightness = Math.max(0.01f, Prefs.get(this, Prefs.BRIGHT) / 100f);
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        w.setAttributes(lp);

        view = new LedView(this);
        setContentView(view);
        view.setOnClickListener(v -> finish());
        apply(getIntent());

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(rx, f);
        rxOn = true;

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(LedService.NOTIF_ID);
        arm();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        apply(intent);
        view.start();
        arm();
    }

    private void apply(Intent i) {
        int[] cols = i == null ? null : i.getIntArrayExtra("c");
        if (cols == null || cols.length == 0) cols = new int[]{Prefs.get(this, Prefs.C_OTHER)};
        view.config(cols, Prefs.get(this, Prefs.STYLE), Prefs.get(this, Prefs.ANIM),
                Prefs.get(this, Prefs.POSX), Prefs.get(this, Prefs.POSY),
                UI.dp(this, Prefs.get(this, Prefs.SIZE)));
    }

    /** Safety timeout, plus the optional "turn the screen off after the glow". */
    private void arm() {
        h.removeCallbacksAndMessages(null);
        h.postDelayed(giveUp, 120000);
        if (Prefs.on(this, Prefs.LOCK) && adminActive()) {
            h.postDelayed(lock, Prefs.get(this, Prefs.GLOW) * 1000L);
        }
    }

    private boolean adminActive() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            return dpm != null && dpm.isAdminActive(new ComponentName(this, AdminReceiver.class));
        } catch (Exception e) {
            return false;
        }
    }

    private void lockNow() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            if (dpm != null) dpm.lockNow();
        } catch (Exception ignored) {
        }
        finish();
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onResume() {
        super.onResume();
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        view.start();
    }

    @Override
    protected void onPause() {
        view.stop();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        if (rxOn) {
            try {
                unregisterReceiver(rx);
            } catch (Exception ignored) {
            }
            rxOn = false;
        }
        super.onDestroy();
    }
}
