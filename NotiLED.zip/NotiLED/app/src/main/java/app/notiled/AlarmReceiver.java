package app.notiled;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        LedService s = LedService.inst;
        if (s == null || intent == null) return; // not connected: the service re-arms itself on connect
        if (Alarms.TEST.equals(intent.getAction())) s.test();
        else s.onRepeat();
    }
}
