# Components declared in the manifest are kept automatically by AAPT2 rules.
