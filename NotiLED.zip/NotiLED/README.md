# Notification Light (ضوء الإشعارات)

Brings back the old notification LED: a small glowing light on a pure black screen that shows
charging, battery full, low battery and app notifications, each in its own color.
Built for AMOLED/OLED (black pixels are off, so only the glowing spot uses power) and works on any screen.

* No libraries, no foreground service, no polling, no wake locks -> tiny APK, near-zero RAM/battery.
* Pure Java + Android framework APIs, so one APK runs on every CPU (ARM, ARM64, x86) and every brand.
* minSdk 21 (Android 5.0), targetSdk 36 (Android 16). English + Arabic.

## Build the APK

### Option A: Android Studio (easiest)
1. Install Android Studio, choose **Open**, select this folder, wait for Gradle sync.
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and install.

For the smallest file use the **release** variant (`Build Variants` panel), output in
`app/build/outputs/apk/release/`. It is signed with the debug key so it installs directly;
use your own keystore if you publish to a store.

### Option B: no install, build online
Upload the folder to a GitHub repository. The included workflow `.github/workflows/build.yml`
builds the APK on every push; download it from the Actions tab (artifact **NotiLED-apk**).

### Option C: command line
`./gradlew assembleRelease` (needs JDK 17 and the Android SDK).

## First run on the phone
1. Open the app and tap **Grant** for each item shown (notification access; allow notifications;
   full-screen notifications on Android 14+).
2. Press **Test the light** and turn the screen off.
3. Optional: on Xiaomi / Huawei / Oppo / Vivo / Samsung, set the app's battery mode to
   "No restrictions" and allow "Display over lock screen" / auto-start, otherwise the brand's
   battery saver may stop the light.

## How it saves power
The system itself keeps the notification listener alive, so the app adds no process of its own.
When something arrives while the screen is off, a black screen with a tiny dot shows over the
lock screen at low brightness and disappears with the normal screen timeout. Repeats use
inexact alarms, not wake locks. "Turn the screen off after the glow" shortens it further.

## Files
`LedService` listener + battery logic - `LedActivity`/`LedView` the light - `MainActivity` and
`AppsActivity` settings - `Prefs` settings storage - `Alarms` repeat timers.
